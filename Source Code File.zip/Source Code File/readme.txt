Name of the program: 
Newbee12.pro
Name of the code: 
ALPHA MODEL

Authors:  
Hao Weng, Zhengyang Liu, Dayong Wang
Key Laboratory of Ocean Energy Utilization and Energy Conservation of Ministry of Education, School of Energy and Power Engineering, Dalian University of Technology, Dalian 116023, P. R. China
  
Corresponding author. 
Dayong Wang
School of Energy and Power Engineering 
Dalian University of Technology 
2 Linggong Road 
Dalian 116023 
P. R. China 

Contact Email: wangdy@dlut.edu.cn

Title of the manuscript: 
ALPHA MODEL: A C++ Code for Modeling and Analyzing Hydrate-saturation-dependent Permeability of Hydrate-bearing Sediments
--------------------------------------------------------------------------------------------------------------------------
The helpfile.txt contains instruction guide that provides information on how to use the program.
The test data is excel_example.xlsx


